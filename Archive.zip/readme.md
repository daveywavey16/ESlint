# eslint-config-coda

This package provides CODA's extended JavaScript ESlint configuration, supplementing the base configuration with React and JSX-Aria linting rules.

## Usage

**Prequesite:** Node must be installed (but you knew that already, didn't you?)

1. Install Eslint

   `$ npm install -g eslint@latest`
2. Configure your editor to integrate with ESlint
   - [Visual Studio Code](https://code.visualstudio.com/) with the [ESLint Extension](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
   - [Sublime Text](https://www.sublimetext.com/) with [SublimeLinter-eslint](https://github.com/SublimeLinter/SublimeLinter-eslint)
   - [Atom](https://ide.atom.io/) with [linter-eslint](https://atom.io/packages/linter-eslint)
   - [JetBrain's](https://www.jetbrains.com/) with [ESLint](https://plugins.jetbrains.com/plugin/7494-eslint)
3. Add the package to the *devDependencies* section of your `package.json`

   `$ npm install --save-dev eslint-config-coda@latest`
4. Add the following peer dependencies to your *devDependencies* section:
  - `$ npm install --save-dev eslint-plugin-import@latest`
  - `$ npm install --save-dev eslint-plugin-jsx-a11y@latest`
  - `$ npm install --save-dev eslint-plugin-react@latest`
5. Add `"extends": "coda"` to your .eslintrc.
6. :sparkles: Start linting! :sparkles:

## Contributing

Feel free to suggest changes to the rules.
Before submitting a pull request please ensure that:

`$ npm run prepublishOnly`

Runs successfully without any errors.

## Publishing

To publish this repo, please:
- Bump the version in `package.json`
- Authenticate as the npm user
- run `npm publish`